document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const emailError = document.getElementById("emailError");
    const passwordError = document.getElementById("passwordError");
    const apiMessage = document.getElementById("apiMessage");

    let valid = true;

    // Reset error messages
    emailError.style.display = "none";
    passwordError.style.display = "none";
    apiMessage.innerHTML = "";

    // Email validation
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        emailError.style.display = "block";
        emailError.textContent = "Please enter a valid email address.";
        valid = false;
    }

    // Password validation
    if (password.length < 6) {
        passwordError.style.display = "block";
        passwordError.textContent = "Password must be at least 6 characters long.";
        valid = false;
    }

    if (!valid) return;

    // API call simulation
    fetch('https://jsonplaceholder.typicode.com/posts', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            username: email,
            password: password,
        }),
    })
        .then(response => response.json())
        .then(data => {
            apiMessage.textContent = "Login successful!";
            apiMessage.style.color = "green";
        })
        .catch(error => {
            apiMessage.textContent = "Login failed. Please try again.";
            apiMessage.style.color = "red";
        });
});
